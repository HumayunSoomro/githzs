// import Nokia from "./mobile.js";
// const n = new Nokia();
// n.volumeUp();

// import show from "./mobile.js";
// show();

// import a from "./mobile.js";
// console.log(a);

// import { Nokia } from "./mobile.js";
// const n = new Nokia();
// n.volumeup();

// import { show } from "./mobile.js";
// show();
import * as device from "./mobile.js";
const n = new device.Nokia();
n.volumup();
device.show();
console.log(device.a);
