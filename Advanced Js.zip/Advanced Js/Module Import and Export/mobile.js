// export default class Nokia {
//   volumeUp() {
//     console.log("High Volume");
//   }
// }

// export default function show() {
//   console.log("Humayun");
// }

// const a = 10;
// export default a;

// export class Nokia {
//   volumeup() {
//     console.log("sdk");
//   }
// }

// export function show() {
//   console.log("hbl");
// }

export class Nokia {
  volumup() {
    console.log("hbl");
  }
}
export function show() {
  console.log("psl");
}

export const a = 8;
